<?php



$id=$_REQUEST['id'];
$newname=$_REQUEST['newname'];
$newemail=$_REQUEST['newemail'];
mysql_connect("localhost", "root", "") or die ("problems with connection");
mysql_select_db("frozen");
mysql_query("UPDATE users SET name='$newname', email='$newemail' WHERE id='$id'") ;

echo "update successful";
mysql_close();







?>
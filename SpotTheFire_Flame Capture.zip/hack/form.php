<html>	
<head>
<title> FORMS
</title>
</head>
<body>
<center><h2>REGISTER ON FREEZE </h2></center>

 <form   ENCTYPE="multipart/form-data" method="post" action="insertf.php">
 <center>
 <table border="0" width="20%">
<tr><td width=10%>Name:</td> <td> <input type="text" name="name" max length ="15"></td></br>
<tr><td width=10%>Email: </td> <td><input type="text" name="email" max length ="30"></td></br>
<tr><td width=10%>Adress: </td> <td><input type="text" name="adress" ></td>
 </table>
<p>
Upload your blueprint:<input type="file" name="file"><p>
<input type="submit" name="submit" value="submit">
</center>
 </form>

 
 

</body>
</html>
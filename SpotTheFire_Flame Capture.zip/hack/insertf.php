<?php


$name = $_POST['name'];
$email = $_POST['email'];
$adress = $_POST['adress'];

if ($name && $email && $adress){
	 if (preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)) {
	

     mysql_connect("localhost", "root", "") or die("could not be connected" );
	 mysql_select_db("frozen");
	 $name=mysql_query("SELECT name FROM users WHERE name='$name'");
     $count=mysql_num_rows($name);
     $remail=mysql_query("SELECT email FROM users WHERE email='$email'");
     $checkemail=mysql_num_rows($remail);
	     if($checkemail!=0){
		                         echo"This email has already been registered";
	                        }else{
															if (isset($_POST['submit'])) {
	$file =$_FILES['file'];

	$fileName =$_FILES['file']['name'];
	$fileTmpName =$_FILES['file']['tmp_name'];
	$fileSize =$_FILES['file']['size'];
	$fileError =$_FILES['file']['error'];
	$fileType =$_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));
    $allowed  = array('jpg', 'jpeg', 'png', 'pdf');

   if (in_array($fileActualExt, $allowed)) {
   	 if ($fileError === 0) {
   	 	 if ($fileSize < 1000000) {
   	 	  $fileNameNew = uniqid('',true).".".$fileActualExt;
   	 	  $fileDestination ='uploads/'.$fileNameNew;
   	 	  move_uploaded_file($fileTmpName, $fileDestination);
   	 	  header("location: updatef.php?uploadsuccess");
   	 	 }else{
   	 	 	echo "your file is too big";
   	 	 }
   	 }else{
   	echo "there was an error uploading this file";
   }

   }else{
   	echo "you cannot upload files of this type";
   }


}
						mysql_query("INSERT INTO users(name,email,adress) VALUES('$name','$email','$adress')");
						echo "You have succefully registered!<a href='home.php'>Login now!</a>";
					
					
							         
						        } 
	           }else{
				   "enter a valid email adress";
			   }


} else
{
	echo"you have to complete the form";
}


?>
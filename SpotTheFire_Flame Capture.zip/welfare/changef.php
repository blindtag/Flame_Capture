<?php



$id=$_REQUEST['id'];
$newname=$_REQUEST['newname'];
$newemail=$_REQUEST['newemail'];
mysqli_connect("localhost", "root", "") or die ("problems with connection");
mysqli_select_db("frozen");
mysqli_query("UPDATE users SET name='$newname', email='$newemail' WHERE id='$id'") ;

echo "update successful";
mysqli_close();







?>
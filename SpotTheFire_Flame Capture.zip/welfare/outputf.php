<?php

mysqli_connect("localhost", "root", "");
mysqli_select_db("frozen");
$result= mysqli_query("SELECT * FROM users ");
while($row = mysqli_fetch_array($result)){
	echo $row['name']. " ". $row['email']." ".$row['adress'];
	echo "<br/>";
}
 



?>
<html>
<head>


</head>

<body>


<h3> Edit User: <?php echo $_REQUEST['names'] ?>       </h3>

<form method="POST" action="changef.php">

<table border="0" width="60%">
<tr><td width="30%">Building:</td> <td><input type="text" name="newname"
 value ="<?php echo $_REQUEST['names']; ?> "></td></tr>
<tr><td width="30%">Email:</td> <td><input type="text" name="newemail"
value="<?php echo $_REQUEST['emails'];?>"></td></tr>
<tr><td width="30%">Adress:</td><td><input type="password" name="newpassword"
value="<?php echo $_REQUEST['passwords'];?>"></td></tr></table>


<input type="submit" value="save & update">
<input type="hidden" name="id" value="<?php echo $_REQUEST['ids'];?>">
<form>
 
 

 
 
</body>



</html>
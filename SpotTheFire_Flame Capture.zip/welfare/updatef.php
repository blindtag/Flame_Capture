<?php

echo "<center><h3>Choose an i.d to send a message to</h3></center>";
mysqli_connect("localhost", "root", "") or die("problem with connection");
mysqli_select_db("frozen");


           $per_page= 6;
           $pages_query= mysqli_query("SELECT COUNT('id') FROM users");
           $pages= ceil(mysqli_result($pages_query, 0)/ $per_page);

          $page= (isset($_GET['page'])) ?(int)$_GET['page'] : 1;
          $start=($page - 1) * $per_page;
          $query = mysqli_query("SELECT * FROM users LIMIT $start, $per_page");



echo "<table width =\"90%\" align=center border=2>";
echo "<tr><td width = \"10%\" align=center bgcolor='#3498db'>ID</td>
<td width =\"20%\" align=center bgcolor='#3498db'>Name</td>
<td width =\"30%\" align=center bgcolor='#3498db'>Email</td>
<td width =\"40%\" align=center bgcolor='#3498db'>Adress</td></tr>";

while ($row = mysqli_fetch_assoc($query)){
	$id=$row['id'];
	$name=$row['name'];
	$email=$row['email'];
    $adress=$row['adress'];

	
	
	echo "<tr><td align=center>
	<a href=\"edit.php?ids=$id&names=$name&emails=$email&adresss=$adress\">$id</a>
     <td>$name</td><td><a href=\"emailto.php?emails=$email\">$email</a></td><td>$adress</td></tr>";
	 
    }echo"</table>";

echo "<center>";
$prev= $page - 1;
$next= $page + 1;

        if(!($page<=1)){
echo "<a href='update.php?page=$prev'>prev</a>&nbsp";
               }
       if($pages>=1){
		   
		for($x=1;$x<=$pages;$x++){
			          echo ($x==$page) ? ' <b><a href="?page='.$x.'">'.$x.'</a></b> ' :'<a href="?page='.$x.'">'.$x.'</a> ';
	
                                 }   
	                  }
if(!($page>=$pages)){
echo "<a href='updatef.php?page=$next'>next</a>";
}
 

mysqli_close();


?>